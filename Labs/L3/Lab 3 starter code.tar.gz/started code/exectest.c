#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#define UNUSED __attribute__((unused))



int main(UNUSED int argc, UNUSED char *argv[]) {
	
	
	return EXIT_FAILURE;
}
