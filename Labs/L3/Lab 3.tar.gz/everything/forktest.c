#include <sys/types.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>
#define UNUSED __attribute__((unused))

int main(UNUSED int argc, UNUSED char *argv[]) {
		pid_t id;	/* POSIX says that pid_t is a signed int */
	
/* parent */	id = fork();
/*  both  */	switch (id) {
/* parent */	case -1: fprintf(stderr, "fork() call failed.\n");
/* parent */		 return EXIT_FAILURE;
/* child  */	case 0: /* child branch */
/* child  */		printf("Child: my PID %d, parent PID %d\n", getpid(), getppid());
/* child  */		break;
/* parent */	default: /* parent branch */
/* parent */		printf("Parent: my PID %d, child PID %d\n", getpid(), id);
/* parent */		wait(NULL); /* wait for child to terminate */
/* parent */		break;
		}
/*  both  */	return EXIT_SUCCESS;
}
