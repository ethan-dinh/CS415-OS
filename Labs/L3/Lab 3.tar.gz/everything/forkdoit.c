#include <sys/types.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>

int main(int argc, char *argv[]) {
		pid_t id;	/* POSIX says that pid_t is a signed int */
	
/* parent */	id = fork();
/*  both  */	switch (id) {
/* parent */	case -1: fprintf(stderr, "fork() call failed.\n");
/* parent */		 return EXIT_FAILURE;
/* child  */	case 0: /* child branch */
/* child  */		execvp(argv[1], argv+1);
/* child  */		fprintf(stderr, "execvp() failed!\n");
/* child  */            return EXIT_FAILURE;
/* parent */	default: /* parent branch */
/* parent */		wait(NULL); /* wait for child to terminate */
/* parent */		break;
		}
/* parent */	return EXIT_SUCCESS;
}
