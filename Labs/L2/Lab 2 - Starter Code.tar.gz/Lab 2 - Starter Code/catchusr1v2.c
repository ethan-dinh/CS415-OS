#include <signal.h>
#include <stdlib.h>
#include <stdio.h>
#include <time.h>
#include <stdbool.h>
#define UNUSED __attribute__((unused))


int main(int argc, char *argv[]) {
	return EXIT_SUCCESS;
}
