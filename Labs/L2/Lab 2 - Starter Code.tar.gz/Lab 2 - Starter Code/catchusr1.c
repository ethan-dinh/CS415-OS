#include <signal.h>
#include <stdlib.h>
#include <stdio.h>
#include <time.h>
#include <stdbool.h>
#define UNUSED __attribute__((unused))


int main(UNUSED int argc, UNUSED char *argv[]) {
	return EXIT_SUCCESS;
}
